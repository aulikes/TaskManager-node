import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { RabbitMqClientProvider } from './rabbitmq-client.provider';
import { AppLogger } from '../../../logger/app.logger';

@Module({
  imports: [ConfigModule],
  providers: [RabbitMqClientProvider, AppLogger],
  exports: [RabbitMqClientProvider],
})
export class RabbitMQModule {}

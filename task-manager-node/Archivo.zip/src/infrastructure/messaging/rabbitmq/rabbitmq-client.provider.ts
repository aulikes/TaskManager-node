import { ClientProxyFactory, Transport } from '@nestjs/microservices';
import { ConfigService } from '@nestjs/config';
import { Provider } from '@nestjs/common';
import { getRabbitMqUri } from '../../util/get-rabbitmq-uri'; 

export const RabbitMqClientProvider: Provider = {
  provide: 'RABBITMQ_CLIENT',
  useFactory: (configService: ConfigService) => {
    const uri = getRabbitMqUri(configService);
    return ClientProxyFactory.create({
      transport: Transport.RMQ,
      options: {
        urls: [uri],
        queue: '', // <- el productor no necesita declararse en una cola
        queueOptions: { durable: false }, // <- se ignora, es requerido pero no se usa
        exchange: configService.getOrThrow('RABBITMQ_EXCHANGE'),
      },
    });
  },
  inject: [ConfigService],
};

import { Injectable, Inject } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ClientProxy } from '@nestjs/microservices';
import { TaskCreatedEventPublisher } from '../../../application/port/out/task-created-event.publisher';
import { TaskCreatedEvent } from '../../../domain/event/task-created.event';
import { AppLogger } from '../../../logger/app.logger';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class RabbitTaskCreatedEventPublisher implements TaskCreatedEventPublisher {
  constructor(
    @Inject('RABBITMQ_CLIENT') private readonly client: ClientProxy,
    private readonly config: ConfigService,
    private readonly logger: AppLogger,
  ) {}

  async publish(event: TaskCreatedEvent): Promise<void> {
    const payload = { ...event };
    const routingKey = this.config.getOrThrow<string>('TASK_CREATED_ROUTING_KEY');
    this.logger.log(`Publishing task.created event: ${JSON.stringify(payload)}`);

    try {
      await firstValueFrom(this.client.emit(routingKey, payload));
      this.logger.log('task.created event published successfully');
    } catch (err) {
      this.logger.error('Failed to publish task.created event', err);
    }
  }
}

import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { TaskCreatedEvent, TaskCreatedEventSchema } from './schema/task-created-event.schema';
import { TaskCreatedListener } from './controller/listener/task-created.listener';
import { TaskCreatedService } from './service/task-created.service';
import { AppLogger } from './logger/app.logger';
import { HealthModule } from './health/health.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    HealthModule,

    // Conexión a MongoDB usando Mongoose
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        uri: config.get<string>('MONGODB_URI'),
      }),
    }),
    MongooseModule.forFeature([
      { name: TaskCreatedEvent.name, schema: TaskCreatedEventSchema },
    ]),
  ],
  controllers: [],
  providers: [
    TaskCreatedListener, 
    AppLogger, 
    TaskCreatedService
  ],
})
export class AppModule {}

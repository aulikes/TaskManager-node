import { ConfigService } from '@nestjs/config';
import { RmqOptions, Transport } from '@nestjs/microservices';
import { getRabbitMqUri } from '../util/get-rabbitmq-uri';

/**
 * Devuelve la configuración de RabbitMQ para una cola específica.
 * Esta configuración permite que NestJS enrute correctamente los eventos
 * incluso si no se especifica un "pattern" explícito dentro del mensaje.
 */
export function getRabbitMqConfig(config: ConfigService, queueKey: string): RmqOptions {
  const uri = getRabbitMqUri(config);
  return {
    transport: Transport.RMQ,
    options: {
      urls: [uri],                                     // URI completa, ej: amqp://admin:admin@localhost:5672
      queue: config.getOrThrow(queueKey),              // Ej: TASK_CREATED_QUEUE → task.created.queue
      queueOptions: {
        durable: true,                                 // La cola persiste entre reinicios
      },
      noAck: false,                                     // Usamos acknowledgments manuales (channel.ack)
    },
  };
}

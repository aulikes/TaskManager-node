import { Controller } from '@nestjs/common';
import { EventPattern, Payload, Ctx, RmqContext } from '@nestjs/microservices';
import { AppLogger } from '../../logger/app.logger';
import { TaskCreatedEventDto } from '../dto/task-created-event.dto';
import { TaskCreatedService } from '../../service/task-created.service';
import { TaskCreatedEvent, TaskCreatedEventDocument } from '../../schema/task-created-event.schema';

// Funciones de class-validator y class-transformer
import { validate } from 'class-validator';
import { plainToInstance } from 'class-transformer';

/**
 * Controlador que escucha el evento 'task.created' desde RabbitMQ.
 */
@Controller()
export class TaskCreatedListener {
  constructor(
    private readonly logger: AppLogger,
    private readonly taskCreatedService: TaskCreatedService,
  ) {}

  /**
   * Escucha el evento con routing key 'task.created'.
   * Se ejecuta cada vez que se recibe un mensaje en esa cola.
   */
  @EventPattern('task.created')
  async handleTaskCreated(
    @Payload() data: any,           // Payload recibido del mensaje
    @Ctx() context: RmqContext      // Contexto de RabbitMQ (incluye canal y mensaje original)
  ): Promise<void> {
    // Obtener referencia al canal de RabbitMQ
    const channel = context.getChannelRef();
    const originalMsg = context.getMessage();

    this.logger.log('Received event: task.created');
    this.logger.debug('Raw payload: ' + JSON.stringify(data));

    // Convertir el objeto plano recibido a una instancia del DTO
    const dto = plainToInstance(TaskCreatedEventDto, data);

    // Validar el DTO según las reglas declaradas en TaskCreatedEventDto
    const errors = await validate(dto);

    // Si hay errores de validación, registrar el error y confirmar el mensaje (para no reenviarlo)
    if (errors.length > 0) {
      this.logger.warn('Validation failed for TaskCreatedEvent');
      this.logger.debug('Validation errors: ' + JSON.stringify(errors));
      channel.ack(originalMsg); // Confirmar el mensaje y descartarlo
      return;
    }

    // Si pasa la validación, registrar logs estructurados
    this.logger.log('DTO validated successfully');
    this.logger.debug('Validated DTO: ' + JSON.stringify(dto));

    try {
      this.logger.log('Attempting to persist event to MongoDB');
      // Guarda en MONGO DB
      const taskEvent: TaskCreatedEvent = {
        id: dto.id,
        title: dto.title,
        description: dto.description,
        status: dto.status
      };
      await this.taskCreatedService.saveEvent(taskEvent);
      this.logger.log('Event persisted to MongoDB');
    } catch (err) {
      // Duplicado: el evento ya se guardó antes
      if (err.name === 'MongoServerError' && err.code === 11000) {
        this.logger.warn(`Duplicate event skipped (id: ${dto.id})`);
      } else {
        // Otro error más grave
        this.logger.error('Failed to persist event to MongoDB', err);
        return; // No hacemos ack -> RabbitMQ puede reintentar
      }
    }
    // Confirmar el mensaje para que RabbitMQ lo considere procesado
    channel.ack(originalMsg);
  }
}
